package com.example.calculatorapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Declaring the variables
        var btn_add = findViewById<Button>(R.id.btn_add)
        var btn_sub = findViewById<Button>(R.id.btn_sub)
        var btn_multi = findViewById<Button>(R.id.btn_multi)
        var btn_divide = findViewById<Button>(R.id.btn_divide)
        var btn_sqrt = findViewById<Button>(R.id.btn_sqrt)
        var btn_pwr = findViewById<Button>(R.id.btn_pwr)
        var ipt_one = findViewById<TextView>(R.id.ipt_one)
        var ipt_two = findViewById<TextView>(R.id.ipt_two)
        var opt_results = findViewById<TextView>(R.id.opt_results)
        val btn_clear = findViewById<Button>(R.id.btn_clear)
        var btn_advance = findViewById<Button>(R.id.btn_advance)


        //These listeners specify what should happen when each button is clicked
        btn_add.setOnClickListener {
            val num1 = ipt_one.text.toString().toInt()
            val num2 = ipt_two.text.toString().toInt()

            val result = num1 + num2
            //The results of these calculations are displayed
            opt_results.text = "$num1 + $num2 = $result"

        }
        btn_sub.setOnClickListener {
            val num1 = ipt_one.text.toString().toInt()
            val num2 = ipt_two.text.toString().toInt()

            val result = num1 - num2
            opt_results.text = "$num1 - $num2 = $result"

           }
        btn_multi.setOnClickListener {
            val num1 = ipt_one.text.toString().toInt()
            val num2 = ipt_two.text.toString().toInt()

            val result = num1 * num2
            opt_results.text = "$num1 x $num2 = $result"
    }

        btn_divide.setOnClickListener {
            val num1 = ipt_one.text.toString()
            val num2 = ipt_two.text.toString()

            //shows an error message if no number is entered into num2
            if (num2.isEmpty()) {
                opt_results.text = "Error: Please enter a valid second number"
            } else {
                val num1 = num1.toInt()
                val num2 = num2.toInt()

                //error message if a zero is typed in to num2
                if (num2 == 0) {
                    opt_results.text = "Error: Division by 0 is not allowed"
                } else {
                    val result = num1 / num2
                    opt_results.text = "$num1 ÷ $num2 = $result"
                }
            } }

                btn_sqrt.setOnClickListener {
                    val num1 = ipt_one.text.toString()

                    if (num1.isEmpty()) {
                        opt_results.text = "Error: Please enter a valid number"
                    } else {
                        val num1 = num1.toDouble()

                        if (num1 < 0) {
                            // Calculate the square root of the absolute value and add "i"
                            val result = Math.sqrt(Math.abs(num1))
                            opt_results.text = "sqrt($num1) = ${result}i"
                        } else {
                            val result = Math.sqrt(num1)
                            opt_results.text = "sqrt($num1) = $result"
                        }

                        btn_pwr.setOnClickListener {
                            val num1 = ipt_one.text.toString().toInt()
                            val num2 = ipt_two.text.toString().toInt()

                            var result = 1.0 // Initialize the result to 1

                            // Check if num2 is negative for negative exponents
                            if (num2 < 0) {
                                for (i in 1..Math.abs(num2)) {
                                    result /= num1.toDouble()
                                }
                            } else {
                                for (i in 1..num2) {
                                    result *= num1.toDouble()
                                }
                            }

                            opt_results.text = "$num1^$num2 = $result"
                        }
            // It clears the contents of ipt_one, ipt_two, and opt_results when clicked.
            btn_clear.setOnClickListener {
                ipt_one.setText("")
                ipt_two.setText("")
                opt_results.setText("")
            }
        }}
    btn_advance.setOnClickListener {
        val intent= Intent(this, advanced::class.java)
        startActivity(intent)
    }

    }}









