package com.example.calculatorapp

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity




class advanced : AppCompatActivity() {
    private val numbersList = mutableListOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_advanced)

        var btn_add = findViewById<Button>(R.id.btn_add)
        var btn_average = findViewById<Button>(R.id.btn_average)
        var btn_minmax = findViewById<Button>(R.id.btn_minmax)
        var btn_clear = findViewById<Button>(R.id.btn_clear)
        var ipt_one = findViewById<TextView>(R.id.ipt_one)
        var store_results = findViewById<TextView>(R.id.store_results)
        var opt_results = findViewById<TextView>(R.id.opt_results)

        btn_add.setOnClickListener {
            val num1 = ipt_one.text.toString().toIntOrNull()
        //allows you to add in numbers and stores them
            if (num1 != null) {
                if (numbersList.size < 10) {
                    numbersList.add(num1)
                    ipt_one.text = "" // Clears the input field when a number is added
                    store_results.text = "Numbers stored: ${numbersList.joinToString(", ")}"
                } else {
                    // Displays a toast message if you add more than 10 numbers
                    Toast.makeText(this, "You can only add up to 10 numbers", Toast.LENGTH_SHORT).show()
                }
            } else {
                // Displays a toast message if the number entered is invalid
                Toast.makeText(this, "Please enter a valid number", Toast.LENGTH_SHORT).show()
            }
        }

        btn_average.setOnClickListener {
        //if statement for the numberList
            if (numbersList.isNotEmpty()) {
                val sum = numbersList.sum()
                //Provides the calculations of average using the stored numbers
                val average = sum.toDouble() / numbersList.size
                opt_results.text = "Avg=(${numbersList.joinToString("+")})/${numbersList.size}=${"%.1f".format(average)}"
            } else {
                opt_results.text = "No numbers to calculate average"
            }
        }

        btn_minmax.setOnClickListener {
        //if statement for the numberList
            if (numbersList.isNotEmpty()) {
                val sum = numbersList.sum()
                //Provides the min/max from the numberList
                val minNumber = numbersList.min()
                val maxNumber = numbersList.max()
                opt_results.text = "Minimum number: $minNumber Maximum number: $maxNumber"
            } else {
                opt_results.text = "No numbers to calculate min/max"
            }



        }
        //clears all stored numbers and calculations
        btn_clear.setOnClickListener {
            ipt_one.setText("")
            opt_results.setText("")
            store_results.setText("")
            numbersList.clear()
        }
    }








}
